package pl.marcinstramowski.shoppinglist.extensions

import android.widget.EditText

fun EditText.clear() {
    setText("")
}
