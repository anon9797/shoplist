package pl.marcinstramowski.shoppinglist.utils

interface UniqueId {
    fun getUniqueId(): Long
}