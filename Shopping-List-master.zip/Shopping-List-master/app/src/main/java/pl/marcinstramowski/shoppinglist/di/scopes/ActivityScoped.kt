package pl.marcinstramowski.shoppinglist.di.scopes

import javax.inject.Scope

@MustBeDocumented
@Scope
@Retention
annotation class ActivityScoped
